/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.util.List;

/**
 *
 * @author Andrea Plascencia
 * @param <T> Hace referencia a una clase del paquete Modelo
 * @param <K> El id que identifica a un objeto de la clase Modelo
 * 
 */
public interface IDAO <T, K> {
    
    void insertar(T a) throws DAOException;
    void modificar(T a) throws DAOException;
    void eliminar(K id) throws DAOException;
    T obtener(K id) throws DAOException;
    
}//Fin de la interface IDAO
