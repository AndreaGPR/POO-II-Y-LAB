/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Andrea Plascencia
 */
public class Galeria {
    
    //Campos o propiedades
    private int idGaleria;
    private String nombreGaleria;
    private String calle;
    private String colonia;
    private String ciudad;
    private String estado;
    private String pais;
    private int codigoPostal;
    
    
    //Constructor sin parámetros
    public Galeria () {
        
    }
    
    //Constructor con siete parámetros
    public Galeria (String nombreGaleria, String calle, String colonia, 
            String ciudad, String estado, String pais, int codigoPostal) {
        this.setNombreGaleria(nombreGaleria);
        this.setCalle(calle);
        this.setColonia(colonia);
        this.setCiudad(ciudad);
        this.setEstado(estado);
        this.setPais(pais);
        this.setCodigoPostal(codigoPostal);
    }
    
    //Constructor con ocho parámetros
    public Galeria (int idGaleria, String nombreGaleria, String calle, String colonia, 
            String ciudad, String estado, String pais, int codigoPostal) {
        this.setIdGaleria(idGaleria);
        this.setNombreGaleria(nombreGaleria);
        this.setCalle(calle);
        this.setColonia(colonia);
        this.setCiudad(ciudad);
        this.setEstado(estado);
        this.setPais(pais);
        this.setCodigoPostal(codigoPostal);
    }
    
    //Descriptores de acceso

    /**
     * @return the idGaleria
     */
    public int getIdGaleria() {
        return idGaleria;
    }

    /**
     * @param idGaleria the idGaleria to set
     */
    public void setIdGaleria(int idGaleria) {
        this.idGaleria = idGaleria;
    }

    /**
     * @return the nombreGaleria
     */
    public String getNombreGaleria() {
        return nombreGaleria;
    }

    /**
     * @param nombreGaleria the nombreGaleria to set
     */
    public void setNombreGaleria(String nombreGaleria) {
        this.nombreGaleria = nombreGaleria;
    }

    /**
     * @return the calle
     */
    public String getCalle() {
        return calle;
    }

    /**
     * @param calle the calle to set
     */
    public void setCalle(String calle) {
        this.calle = calle;
    }

    /**
     * @return the colonia
     */
    public String getColonia() {
        return colonia;
    }

    /**
     * @param colonia the colonia to set
     */
    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    /**
     * @return the ciudad
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * @param ciudad the ciudad to set
     */
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * @return the pais
     */
    public String getPais() {
        return pais;
    }

    /**
     * @param pais the pais to set
     */
    public void setPais(String pais) {
        this.pais = pais;
    }

    /**
     * @return the codigoPostal
     */
    public int getCodigoPostal() {
        return codigoPostal;
    }

    /**
     * @param codigoPostal the codigoPostal to set
     */
    public void setCodigoPostal(int codigoPostal) {
        this.codigoPostal = codigoPostal;
    }
      
}//Fin de la clase Galeria
