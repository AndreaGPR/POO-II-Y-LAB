/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Andrea Plascencia
 */
public class Autor {
    
    //Campos o propiedades
    private int idAutor;
    private String nombreAutor;
    private String apellidos;
    
    //Constructor sin parámetros
    public Autor () {
        
    }
    
    //Constructor con dos parámetros
    public Autor(String nombreAutor, String apellidos) {
        this.setNombreAutor(nombreAutor);
        this.setApellidos(apellidos);
    }
    
    //Constructor con tres parámetros
    public Autor(int idAutor, String nombreAutor, String apellidos) {
        this.setIdAutor(idAutor);
        this.setNombreAutor(nombreAutor);
        this.setApellidos(apellidos);
    }
    
    //Descriptores de acceso

    /**
     * @return the idAutor
     */
    public int getIdAutor() {
        return idAutor;
    }

    /**
     * @param idAutor the idAutor to set
     */
    public void setIdAutor(int idAutor) {
        this.idAutor = idAutor;
    }

    /**
     * @return the nombreAutor
     */
    public String getNombreAutor() {
        return nombreAutor;
    }

    /**
     * @param nombreAutor the nombreAutor to set
     */
    public void setNombreAutor(String nombreAutor) {
        this.nombreAutor = nombreAutor;
    }

    /**
     * @return the apellidos
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * @param apellidos the apellidos to set
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    
}//Fin de la clase Autor
